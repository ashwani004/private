# Online_Movie_Ticket_Booking
A web application made with React Js with Redux , Angular 9 ,NodeJs, Next Js and Mongoose to book the ticket in online


# Movie Ticket Booking Module

1. Registration Module
2. Login & logout Module
3. City list Module
4. Theater List Module
5. Movie list Module
6. Seat selection Module
7. Booking Module 
