export class CreateUserDto {
    readonly username: String;
    readonly name: string;
    readonly email: String;
    readonly password: String;
}