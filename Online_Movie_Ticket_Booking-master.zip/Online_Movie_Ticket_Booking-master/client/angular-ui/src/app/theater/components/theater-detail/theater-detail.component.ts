import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-theater-detail',
  templateUrl: './theater-detail.component.html',
  styleUrls: ['./theater-detail.component.scss']
})
export class TheaterDetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
