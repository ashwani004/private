import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-theater-update',
  templateUrl: './theater-update.component.html',
  styleUrls: ['./theater-update.component.scss']
})
export class TheaterUpdateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
