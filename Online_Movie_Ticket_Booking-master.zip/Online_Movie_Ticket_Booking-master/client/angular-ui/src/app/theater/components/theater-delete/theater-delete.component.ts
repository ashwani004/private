import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-theater-delete',
  templateUrl: './theater-delete.component.html',
  styleUrls: ['./theater-delete.component.scss']
})
export class TheaterDeleteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
